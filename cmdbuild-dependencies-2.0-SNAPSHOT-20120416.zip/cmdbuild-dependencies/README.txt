To install the artifacts locally:

linux$   ./install_artifacts.sh
windows> install.artifacts.cmd

To deploy the artifacts to a server (change the server id and url for your Maven repository):

linux$   ./install-artifacts.sh maven.tecnoteca.com http://maven.tecnoteca.com/ext-release-local/
windows> install.artifacts.cmd maven.tecnoteca.com http://maven.tecnoteca.com/ext-release-local/

