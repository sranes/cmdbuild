#!/bin/bash

function main {
	if test -z $1; then
		echo Installing artifacts locally
		maven_filop="install:install-file"
		maven_artop="install"
		do_it
	elif test -z $2; then
		echo 'Usage: install-artifacts [repository_id repository_url]'
	else
		echo Deploying to server $2
		maven_filop="deploy:deploy-file -DrepositoryId=$1 -Durl=$2"
		maven_artop="package deploy:deploy -DaltDeploymentRepository=$1::default::$2"
		do_it
	fi
}

function do_it {
	install_projects
	loop_for_artifacts
}

function install_projects {
	install_project net.sourceforge.sharkwf.shark-core
	install_project net.sourceforge.sharkwf.shark-hsql-emptydb
	install_project net.sourceforge.sharkwf.shark-embedded
	install_project net.sourceforge.sharkwf.shark-ws-plain
}

function install_project {
	BASE_WD=$PWD
	PROJECT_PATH=`echo $1 | tr . /`
	cd $PROJECT_PATH
	mvn $maven_artop clean
	cd $BASE_WD
}

function loop_for_artifacts {
	
	while read winline; do
		artifact=`echo $winline | tr -d "\r"`
		install_artifacts $artifact
	done <"artifact-list.txt"
}

function install_artifacts {
	groupId=$1
	artifactId=$2
	version=$3
	packaging=$4
	jarpath=`echo $groupId | tr . /`

	mvn $maven_filop -Dfile=$jarpath/$artifactId-$version.$packaging \
		-DgroupId=$groupId -DartifactId=$artifactId -Dversion=$version -Dpackaging=$packaging
}

main $1 $2

