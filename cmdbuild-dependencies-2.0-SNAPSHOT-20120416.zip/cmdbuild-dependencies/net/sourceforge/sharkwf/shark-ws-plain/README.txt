The files from this package come from the Shark source package:

Shark/modules/SharkWebService/Plain/conf/tomcat/context.xml.in -> src/main/webapp/META-INF/context.xml
Shark/modules/SharkWebService/Plain/conf/tomcat/server-config.wsdd -> src/main/webapp/WEB-INF/server-config.wsdd
Shark/modules/SharkWebService/Plain/conf/tomcat/web.xml -> src/main/webapp/WEB-INF/web.xml
Shark/modules/SharkWebService/Plain/conf/tomcat/Shark.conf.in -> src/main/resources/Shark.conf
Shark/modules/SharkEJB/Standard/src-servlet/org/enhydra/shark/servlet/SharkInitServlet.java -> src/main/java/org/enhydra/shark/servlet/SharkInitServlet.java

