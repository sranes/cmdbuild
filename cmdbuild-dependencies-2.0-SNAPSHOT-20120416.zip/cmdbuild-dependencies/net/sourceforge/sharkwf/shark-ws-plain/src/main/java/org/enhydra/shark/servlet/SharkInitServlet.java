/**
* Together Workflow Server
* Copyright (C) 2011 Together Teamsolutions Co., Ltd. 
* 
* This program is free software: you can redistribute it and/or modify 
* it under the terms of the GNU General Public License as published by 
* the Free Software Foundation, either version 3 of the License, or 
* (at your option) any later version. 
*
* This program is distributed in the hope that it will be useful, 
* but WITHOUT ANY WARRANTY; without even the implied warranty of 
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
* GNU General Public License for more details. 
*
* You should have received a copy of the GNU General Public License 
* along with this program. If not, see http://www.gnu.org/licenses
*/

package org.enhydra.shark.servlet;

/**
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * <p>
 * Company:
 * </p>
 * 
 * @author Vladimir Radisic
 * @version 1.0
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Status;
import javax.transaction.UserTransaction;

import org.enhydra.shark.Shark;

/**
 * This servlet is used for Shark Engine initialization.
 */
public class SharkInitServlet extends HttpServlet {

   /**
    * Constant value that represents Shark.conf file parameter
    */
   public static final String ENVIRONMENT_TYPE = "EnvironmentType";

   public void init() throws ServletException {

      System.out.println("++++++++++++++++++++++++++++++++++++++ init - start");

      UserTransaction t = null;
      try {
         Properties props = new Properties();
         File sc = null;
         try {
            File orig = new File(getServletContext().getRealPath("/"));
            sc = new File(orig.getCanonicalPath() + "/conf/Shark.conf");
            if (!sc.exists()) {
               File pjboss = orig.getParentFile().getParentFile().getParentFile().getParentFile();
               sc = new File(pjboss.getCanonicalPath() + "/sharkFiles/conf/Shark.conf");
            }
         } catch (Throwable ex) {
            ex.printStackTrace();
         }
         InputStream is = null;
         try {
            if (sc != null && sc.exists()) {
               is = new FileInputStream(sc.getCanonicalPath());
               System.out.println("Shark will be configured from file "+sc.getCanonicalPath());
            } else {
               URL u = SharkInitServlet.class.getClassLoader().getResource("Shark.conf");
               System.out.println("Shark will be configured from the resource file "+u);
               URLConnection urlConnection = u.openConnection();
               is = urlConnection.getInputStream();
            }
            props.load(is);
         } catch (Throwable e) {
            e.printStackTrace();
         } finally {
            try {
               is.close();
            } catch (Exception ex) {
            }
         }

         String environmentType = (String) props.get(ENVIRONMENT_TYPE);
         System.out.println("environmentType= " + environmentType);

         if (environmentType != null && environmentType.equalsIgnoreCase("tomcat")) {
            t = (UserTransaction) new InitialContext().lookup("java:comp/env/UserTransaction");
         } else {
            t = (UserTransaction) new InitialContext().lookup("java:comp/UserTransaction");
         }

         System.out.println("    t= " + t);

         t.begin();

         System.out.println("	pre configure . . . . . .");
         Shark.configure(props);

         System.out.println("	pre getConnection . . . . . .");
         Shark.getInstance().getSharkConnection();

         System.out.println("	pre commit . . . . . .");
         t.commit();

         System.out.println("++++++++++++++++++++++++++++++++++++++ init - end");

      } catch (Throwable ex) {
         ex.printStackTrace();
         try {
            if (t.getStatus() != Status.STATUS_NO_TRANSACTION)
               t.rollback();
         } catch (Exception e) {
            System.out.println("++++++++++++++++++++++++++++++++++++++ init - error!!!");
            e.printStackTrace();
         }
         throw new Error("Unable to put shark into the running state!");

      }
   }

   public void doGet(HttpServletRequest req, HttpServletResponse res)
      throws ServletException,
         IOException {

      res.setContentType("text/plain");
      PrintWriter out = res.getWriter();
      out.println("*****************************************************************");
      out.println("***** This servlet is used for Shark Engine initialization! *****");
      out.println("*****************************************************************");

      System.out.println("++++++++++++++++++++++++++++++++++++++ doGet");
   }
}
